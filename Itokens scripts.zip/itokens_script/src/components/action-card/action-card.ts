import { Component } from '@angular/core';

@Component({
  host: { class: 'card' },
  selector: 'action-card',
  templateUrl: 'action-card.html'
})
export class ActionCardComponent {}
